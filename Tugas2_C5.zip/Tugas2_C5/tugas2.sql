-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2021 at 04:58 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugas2`
--

-- --------------------------------------------------------

--
-- Table structure for table `golongan`
--

CREATE TABLE `golongan` (
  `idGolongan` varchar(5) NOT NULL,
  `Daya` varchar(10) NOT NULL,
  `tarifGolongan` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `golongan`
--

INSERT INTO `golongan` (`idGolongan`, `Daya`, `tarifGolongan`) VALUES
('R1', '450 VA', 274),
('R2', '3300', 1444),
('R3', '6600 VA', 1444);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `idMeteran` int(12) NOT NULL,
  `namaPelanggan` varchar(50) NOT NULL,
  `NIK` int(16) NOT NULL,
  `alamatPelanggan` varchar(50) NOT NULL,
  `idGolongan` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`idMeteran`, `namaPelanggan`, `NIK`, `alamatPelanggan`, `idGolongan`) VALUES
(1135442867, 'Akaba', 1451366121, 'Jl.Mawar no.4 ', 'R2'),
(1144442867, 'Sakaki', 1451434121, 'Jl.Mawar no.3', 'R1');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `idPetugas` int(10) NOT NULL,
  `NamaPetugas` varchar(20) NOT NULL,
  `AlamatPetugas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`idPetugas`, `NamaPetugas`, `AlamatPetugas`) VALUES
(1100, 'Haryanta', 'Jl Pisangan Lama, Dki Jakarta'),
(1200, 'Suparno', ' Jl Jolotundo Baru 15, Jawa Timur'),
(1300, 'Misaki', 'Entahlah gang buntu ');

-- --------------------------------------------------------

--
-- Table structure for table `tagihan`
--

CREATE TABLE `tagihan` (
  `no_tagihan` int(11) NOT NULL,
  `idMeteran` int(12) NOT NULL,
  `tanggalTagihan` date NOT NULL,
  `standAwal` int(20) NOT NULL,
  `standAkhir` int(20) NOT NULL,
  `administrasi` int(20) NOT NULL,
  `angsuran` int(20) NOT NULL,
  `materai` int(20) NOT NULL,
  `idPetugas` int(10) NOT NULL,
  `totalTagihan` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tagihan`
--

INSERT INTO `tagihan` (`no_tagihan`, `idMeteran`, `tanggalTagihan`, `standAwal`, `standAkhir`, `administrasi`, `angsuran`, `materai`, `idPetugas`, `totalTagihan`) VALUES
(1, 1135442867, '2021-10-06', 1000, 2000, 1000, 2000, 5000, 1100, 1452000),
(2, 1144442867, '2021-10-19', 1500, 3000, 1000, 1000, 6000, 1100, 1508000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `golongan`
--
ALTER TABLE `golongan`
  ADD PRIMARY KEY (`idGolongan`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`idMeteran`),
  ADD KEY `FK_golongan` (`idGolongan`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`idPetugas`);

--
-- Indexes for table `tagihan`
--
ALTER TABLE `tagihan`
  ADD PRIMARY KEY (`no_tagihan`),
  ADD KEY `fk_pelanggan` (`idMeteran`),
  ADD KEY `fk_petugas` (`idPetugas`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD CONSTRAINT `FK_golongan` FOREIGN KEY (`idGolongan`) REFERENCES `golongan` (`idGolongan`);

--
-- Constraints for table `tagihan`
--
ALTER TABLE `tagihan`
  ADD CONSTRAINT `fk_pelanggan` FOREIGN KEY (`idMeteran`) REFERENCES `pelanggan` (`idMeteran`),
  ADD CONSTRAINT `fk_petugas` FOREIGN KEY (`idPetugas`) REFERENCES `petugas` (`idPetugas`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
